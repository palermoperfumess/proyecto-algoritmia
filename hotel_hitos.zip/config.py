
FECHA_HOY = "03/10/2025"

FILE_HABITACIONES = 'habitaciones.txt'
FILE_USUARIOS = 'usuarios.txt'
